import DemoOne from "@/components/liquid-glass-demo"

export default function DemoPage() {
  return (
    <main className="grid min-h-screen place-items-center overflow-x-auto bg-[url('/media/q_hang_branca.jpg')] bg-cover bg-center p-4">
      <DemoOne />
    </main>
  )
}
