import { SiteChrome } from "@/components/site/chrome"
import { SiteMain } from "@/components/site/main"
import { SiteFooter } from "@/components/site/footer"
import { ShopPage } from "@/components/site/shop-page"
import { LegalPages } from "@/components/site/legal-pages"
import { Overlays } from "@/components/site/overlays"
import { SiteScripts } from "@/components/site/site-scripts"

export default function Home() {
  return (
    <>
      <SiteChrome />
      <SiteMain />
      <SiteFooter />
      <ShopPage />
      <LegalPages />
      <Overlays />
      <SiteScripts />
    </>
  )
}
