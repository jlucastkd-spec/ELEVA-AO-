import Link from "next/link"

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-[#0c0c0c] p-6 text-center text-[#f1f1f1]">
      <div>
        <h1 className="font-[Oswald,Arial,sans-serif] text-5xl font-semibold uppercase sm:text-7xl">Página não encontrada</h1>
        <p className="mt-3 text-[#a3a2a7]">O endereço que você abriu não existe ou mudou.</p>
        <Link
          href="/"
          className="mt-6 inline-block border border-[#f1f1f1] px-8 py-3 text-xs tracking-[0.06em] uppercase hover:bg-[#f1f1f1] hover:text-[#0c0c0c]"
        >
          Voltar para a Elevação
        </Link>
      </div>
    </main>
  )
}
