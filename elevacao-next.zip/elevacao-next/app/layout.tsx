import type { Metadata, Viewport } from "next"
import { headers } from "next/headers"
import "./globals.css"
import "./site.css"

export const metadata: Metadata = {
  title: "Elevação Store",
  description: "Elevação: moletons, calças, camisetas e acessórios de modelagem ampla. Loja em São Paulo.",
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  // Lê o nonce da política de segurança (middleware.ts). Isso deixa a página dinâmica,
  // e o Next.js aplica o nonce aos próprios scripts.
  const nonce = (await headers()).get("x-nonce") ?? undefined
  return (
    <html lang="pt-BR" data-scroll-behavior="smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          rel="stylesheet"
          nonce={nonce}
          href="https://fonts.googleapis.com/css2?family=Libre+Caslon+Text:wght@700&family=Oswald:wght@400;500;600&family=Inter:wght@400;500&family=IBM+Plex+Mono:wght@400&display=swap"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
