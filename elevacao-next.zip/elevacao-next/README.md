# Elevação Store (Next.js)

Site da loja Elevação em Next.js 15, React 19, TypeScript, Tailwind CSS v4 e componentes shadcn.

## Rodar no computador

```bash
npm install
npm run dev
```

Abra http://localhost:3000. O exemplo do botão de vidro fica em http://localhost:3000/demo.

## Onde mexer

| O que | Arquivo |
| --- | --- |
| Razão social, CNPJ, e-mail, WhatsApp, horário | `lib/site-config.ts` |
| Peças, preços, fotos e onde cada uma aparece | `lib/products.ts` |
| Fotos e vídeo | `public/media/` |
| Visual do site | `app/site.css` |
| Botões de vidro e metal (shadcn) | `components/ui/liquid-glass-button.tsx` |
| Partes da página | `components/site/` |
| Sacola, páginas legais, cookies, animações | `lib/site-script.js` |
| Política de segurança (CSP) | `middleware.ts` |
| Cabeçalhos de segurança | `next.config.ts` |

### Adicionar uma peça

1. Coloque as fotos em `public/media/` e crie a classe da foto em `app/site.css`, junto das outras
   (ex.: `.i-minha-peca { background-image: url(/media/minha-peca.jpg); }`).
2. Em `lib/products.ts`, adicione a peça no `CATALOG` (nome, preço, descrição) e nas listas
   onde ela deve aparecer (`COLLECTION`, `SHOP`, `RAIL_TOP`...).

## Publicar na Vercel

1. Envie esta pasta para um repositório no GitHub.
2. Na Vercel: Add New → Project → importe o repositório. O preset "Next.js" é detectado sozinho.
3. Clique em Deploy.

## Por que existe a pasta `components/ui`

É a pasta padrão do shadcn: o comando `npx shadcn add <componente>` instala os componentes ali,
e as importações usam o caminho `@/components/ui/...`. Manter essa pasta permite adicionar novos
componentes shadcn sem ajustar nada.
