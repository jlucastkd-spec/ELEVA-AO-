import type * as React from "react";
import { HeroActions } from "@/components/elevacao/hero-actions";
import { RailItems, CollectionPages } from "@/components/site/products";
import { MapConsent } from "@/components/site/map-consent";
import { RAIL_TOP, RAIL_BOTTOM } from "@/lib/products";
import { Co } from "@/components/site/co";

// Gerado a partir do site original. Edite à vontade.
export function SiteMain() {
  return (
    <>
      <main id="conteudo" tabIndex={-1}>
        {" "}
        {/* Início */}{" "}
        <section id="inicio" className="hero">
          {" "}
          <video
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            disablePictureInPicture
            poster={"/media/boneco-poster.jpg"}
            aria-label="Manequim girando com moletom de capuz e calça larga pretos"
          >
            <source src={"/media/boneco.mp4"} type="video/mp4" />
          </video>{" "}
          <div className="hero-copy">
            {" "}
            <h1>
              {"Vista sua atitude,"}
              <br />
              {"expresse seu estilo"}
              <br />
              {"e vá além."}
            </h1>{" "}
          </div>
          <HeroActions />
        </section>{" "}
        {/* Arara interativa */}{" "}
        <section className="rack-sec" aria-labelledby="rack-t">
          {" "}
          <p className="rack-tag" id="rack-t">
            {"// coleção 2026 — 7 peças"}
          </p>{" "}
          <p className="rack-brand" aria-hidden="true">
            {"Elevação"}
          </p>{" "}
          <div className="rack">
            {" "}
            <div className="rack-bar" aria-hidden="true"></div>{" "}
            <div className="rack-items">
              {" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "0" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de frente, com o símbolo no peito. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "1" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de costas, com a estrela branca. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "2" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de frente. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "3" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de costas. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "4" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de frente. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "5" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de costas. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
              <button
                type="button"
                className="garment"
                style={{ "--i": "6" } as React.CSSProperties}
                data-garment=""
                data-product="moletom-halo"
                aria-label="Moletom Halo preto, de frente. R$ 289. Clique para escolher o tamanho"
              >
                {" "}
                <span className="swing">
                  <span className="turn">
                    <span className="hook">
                      <svg viewBox="0 0 100 46" aria-hidden="true">
                        <path
                          d="M50 2c-6 0-9 4-8 8 1 3 4 4 6 6l2 3M50 19L4 42h92L50 19"
                          fill="none"
                          stroke="#5d5d61"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="body3d">
                      <span className="shadow"></span>
                      <span className="slice" style={{ "--z": "-0.450" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "-0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.000" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.120" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.230" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.340" } as React.CSSProperties}></span>
                      <span className="slice" style={{ "--z": "0.450" } as React.CSSProperties}></span>
                      <span className="face f-back"></span>
                      <span className="face f-front"></span>
                    </span>
                  </span>
                </span>{" "}
                <span className="g-label" aria-hidden="true">
                  {"Moletom Halo"}
                  <span>{"R$ 289"}</span>
                </span>{" "}
              </button>{" "}
            </div>{" "}
          </div>{" "}
          <p className="rack-hint">{"Passe o mouse ou toque numa peça para ver de frente"}</p>{" "}
        </section>{" "}
        {/* Fileira 1 */}{" "}
        <div className="rail" aria-label="Peças em destaque">
          {" "}
          <div className="rail-track">
            <RailItems cards={RAIL_TOP} />
          </div>{" "}
        </div>{" "}
        {/* Banner 1 */}{" "}
        <section className="banner" aria-label="Coleção Halo">
          {" "}
          <div
            className="fig right i-banner-side"
            role="img"
            aria-label="Manequim de lado com moletom preto e estampa branca na manga"
          ></div>{" "}
          <div className="txt bl reveal">
            {" "}
            <h2>
              {"Preto do capuz"}
              <br />
              {"à barra."}
            </h2>{" "}
            <p>{"Coleção Halo · 2026"}</p>{" "}
          </div>{" "}
        </section>{" "}
        {/* Fileira 2 */}{" "}
        <div className="rail reverse" aria-label="Mais peças">
          {" "}
          <div className="rail-track">
            <RailItems cards={RAIL_BOTTOM} />
          </div>{" "}
        </div>{" "}
        <div className="cta-band">
          {" "}
          <a href="#loja" className="btn-out">
            {"Ver a coleção"}
          </a>{" "}
        </div>{" "}
        {/* Banner 2 */}{" "}
        <section className="banner" aria-label="Moletons">
          {" "}
          <div
            className="fig left i-banner-back"
            role="img"
            aria-label="Manequim de costas mostrando a estrela branca do moletom"
          ></div>{" "}
          <div className="txt r reveal">
            {" "}
            <h2>{"Moletons"}</h2> <p>{"Capuz alto e felpa por dentro"}</p>{" "}
          </div>{" "}
        </section>{" "}
        {/* Coleção */}{" "}
        <section id="colecao">
          {" "}
          <div className="bar wrap">
            {" "}
            <strong>{"Coleção 2026"}</strong>{" "}
            <span>
              <span id="pg-label">{"Página 1 de 3 · arraste para o lado"}</span>
              {" · "}
              <a
                href="#loja"
                style={{ color: "var(--ink)", borderBottom: "1px solid currentColor" } as React.CSSProperties}
              >
                {"Ver tudo"}
              </a>
            </span>{" "}
          </div>{" "}
          <div
            className="pages"
            id="pages"
            tabIndex={0}
            aria-label="Peças da coleção. Arraste para o lado ou use os botões de página."
          >
            <CollectionPages />
          </div>{" "}
          <div className="pager-nav wrap" id="pager-nav">
            {" "}
            <button type="button" data-pg-prev="" aria-label="Página anterior">
              {"←"}
            </button>{" "}
            <button type="button" data-pg="0" aria-label="Página 1" aria-current="true">
              {"1"}
            </button>{" "}
            <button type="button" data-pg="1" aria-label="Página 2">
              {"2"}
            </button>{" "}
            <button type="button" data-pg="2" aria-label="Página 3">
              {"3"}
            </button>{" "}
            <button type="button" data-pg-next="" aria-label="Próxima página">
              {"→"}
            </button>{" "}
          </div>{" "}
        </section>{" "}
        {/* Looks */}{" "}
        <section id="looks">
          {" "}
          <div className="bar wrap">
            {" "}
            <strong>{"Looks"}</strong> <span>{"Halo · 2026"}</span>{" "}
          </div>{" "}
          <div className="looks">
            {" "}
            <div className="ph i-look1 reveal" role="img" aria-label="Look Halo de lado"></div>{" "}
            <div className="ph i-look2 reveal" role="img" aria-label="Look Halo de costas"></div>{" "}
            <div className="ph i-look3 reveal" role="img" aria-label="Look Halo de frente"></div>{" "}
          </div>{" "}
          <div className="cta-band">
            {" "}
            <a href="#loja" className="btn-out">
              {"Ver a coleção"}
            </a>{" "}
          </div>{" "}
        </section>{" "}
        {/* Vitrine flutuante */}{" "}
        <section className="showcase" aria-label="Peças da coleção passando">
          {" "}
          <span className="star s1">
            <svg viewBox="0 0 100 100" fill="currentColor" aria-hidden="true">
              <path d="M50 0 C53 38 62 47 100 50 C62 53 53 62 50 100 C47 62 38 53 0 50 C38 47 47 38 50 0Z" />
            </svg>
          </span>{" "}
          <span className="star s2">
            <svg viewBox="0 0 100 100" fill="currentColor" aria-hidden="true">
              <path d="M50 0 C53 38 62 47 100 50 C62 53 53 62 50 100 C47 62 38 53 0 50 C38 47 47 38 50 0Z" />
            </svg>
          </span>{" "}
          <span className="star s3">
            <svg viewBox="0 0 100 100" fill="currentColor" aria-hidden="true">
              <path d="M50 0 C53 38 62 47 100 50 C62 53 53 62 50 100 C47 62 38 53 0 50 C38 47 47 38 50 0Z" />
            </svg>
          </span>{" "}
          <p className="eyebrow-sc">{"Coleção 2026"}</p> <h2>{"Tudo que está na arara"}</h2>{" "}
          <div className="sc-drift">
            {" "}
            <div className="sc-float">
              {" "}
              <div className="sc-card">
                {" "}
                <div className="sc-track">
                  {" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="moletom-halo"
                    aria-label="Moletom Halo: escolher tamanho"
                  >
                    <div className="ph i-hood-front" role="img" aria-label="Moletom Halo de frente"></div>
                    <div className="lbl">
                      <span>{"Moletom Halo"}</span>
                      <span>{"R$ 289"}</span>
                    </div>
                  </a>{" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="calca-pregas"
                    aria-label="Calça Pregas: escolher tamanho"
                  >
                    <div className="ph i-pants-front" role="img" aria-label="Calça Pregas de frente"></div>
                    <div className="lbl">
                      <span>{"Calça Pregas"}</span>
                      <span>{"R$ 259"}</span>
                    </div>
                  </a>{" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="moletom-halo"
                    aria-label="Moletom Halo · costas: escolher tamanho"
                  >
                    <div className="ph i-hood-back" role="img" aria-label="Costas do Moletom Halo com estrela"></div>
                    <div className="lbl">
                      <span>{"Moletom Halo · costas"}</span>
                      <span>{"R$ 289"}</span>
                    </div>
                  </a>{" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="conjunto-halo"
                    aria-label="Conjunto Halo: escolher tamanho"
                  >
                    <div className="ph i-full-front" role="img" aria-label="Conjunto Halo completo"></div>
                    <div className="lbl">
                      <span>{"Conjunto Halo"}</span>
                      <span>{"R$ 519"}</span>
                    </div>
                  </a>{" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="calca-pregas"
                    aria-label="Calça Pregas · lateral: escolher tamanho"
                  >
                    <div className="ph i-pants-side" role="img" aria-label="Lateral da Calça Pregas com botões"></div>
                    <div className="lbl">
                      <span>{"Calça Pregas · lateral"}</span>
                      <span>{"R$ 259"}</span>
                    </div>
                  </a>{" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="moletom-halo"
                    aria-label="Moletom Halo · manga: escolher tamanho"
                  >
                    <div className="ph i-hood-side" role="img" aria-label="Manga do Moletom Halo"></div>
                    <div className="lbl">
                      <span>{"Moletom Halo · manga"}</span>
                      <span>{"R$ 289"}</span>
                    </div>
                  </a>{" "}
                  <a
                    href="#visite"
                    className="sc-slide"
                    data-product="conjunto-halo"
                    aria-label="Conjunto Halo · costas: escolher tamanho"
                  >
                    <div className="ph i-full-back" role="img" aria-label="Costas do Conjunto Halo"></div>
                    <div className="lbl">
                      <span>{"Conjunto Halo · costas"}</span>
                      <span>{"R$ 519"}</span>
                    </div>
                  </a>{" "}
                  <a href="#visite" className="sc-slide" data-product="moletom-halo" tabIndex={-1} aria-hidden="true">
                    <div className="ph i-hood-front"></div>
                    <div className="lbl">
                      <span>{"Moletom Halo"}</span>
                      <span>{"R$ 289"}</span>
                    </div>
                  </a>{" "}
                </div>{" "}
              </div>{" "}
            </div>{" "}
          </div>{" "}
          <p className="hint-sc">{"Toque na peça para escolher o tamanho"}</p>{" "}
        </section>{" "}
        {/* Sobre + visite */}{" "}
        <div className="info wrap">
          {" "}
          <section id="sobre" className="reveal">
            {" "}
            <h3>{"Sobre a Elevação"}</h3>{" "}
            <p>
              {
                "A loja abriu em 2019 porque a gente não achava uma camiseta preta que continuasse preta depois de dez lavagens. Mandamos fazer uma. Depois veio o moletom, depois a calça."
              }
            </p>{" "}
            <p>
              {
                "A regra continua a mesma: só entra na arara o que a gente usaria. Tecido pesado, modelagem ampla e a mesma tabela de tamanhos, do PP ao XGG, em todas as peças."
              }
            </p>{" "}
          </section>{" "}
          <section id="visite" className="reveal">
            {" "}
            <h3>{"Visite a loja"}</h3>{" "}
            <ul className="rows">
              <li>
                <span>{"Endereço"}</span>
                <span>{"Rua Augusta, 1500 — Consolação, São Paulo, SP"}</span>
              </li>
              <li>
                <span>{"Horário"}</span>
                <span>{"Seg a sex, 10h às 20h · Sábado, 10h às 18h"}</span>
              </li>
              <li>
                <span>{"WhatsApp"}</span>
                <span>
                  <a
                    href="https://wa.me/5511999999999"
                    data-co-href="whatsapp"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Co k="whatsappTxt" />
                  </a>
                </span>
              </li>
              <li>
                <span>{"Instagram"}</span>
                <span>
                  <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer">
                    {"@loja.elevacao"}
                  </a>
                </span>
              </li>
            </ul>{" "}
            <a
              className="btn-out"
              href="https://www.google.com/maps/search/?api=1&query=Rua+Augusta+1500+Sao+Paulo"
              target="_blank"
              rel="noopener noreferrer"
            >
              {"Abrir no Google Maps"}
            </a>{" "}
          </section>{" "}
        </div>{" "}
        <div className="map">
          <MapConsent />
        </div>{" "}
      </main>
    </>
  );
}
