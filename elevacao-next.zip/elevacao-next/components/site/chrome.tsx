import type * as React from "react";

// Gerado a partir do site original. Edite à vontade.
export function SiteChrome() {
  return (
    <>
      <a className="skip" href="#conteudo">
        {"Pular para o conteúdo"}
      </a>
      <div className="urban-bg" aria-hidden="true"></div>
      <div className="intro" aria-hidden="true">
        <span>{"ELEVAÇÃO"}</span>
      </div>
      <header className="head wrap">
        {" "}
        <input
          type="checkbox"
          id="menu-toggle"
          className="menu-toggle"
          aria-label="Menu de navegação"
          aria-controls="menu-drop"
        />{" "}
        <label htmlFor="menu-toggle" className="menu-btn" aria-hidden="true">
          <span></span>
          <span></span>
          <span></span>
        </label>{" "}
        <nav className="left" aria-label="Navegação">
          {" "}
          <a href="#loja">{"Coleção"}</a> <a href="#looks">{"Looks"}</a>{" "}
        </nav>{" "}
        <a href="#inicio" className="logo" aria-label="Elevação — início">
          {"Elevação"}
        </a>{" "}
        <nav className="right" aria-label="Loja">
          {" "}
          <a href="#sobre">{"Sobre"}</a> <a href="#visite">{"Visite a loja"}</a>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </nav>{" "}
        <button type="button" className="cart-btn side-link" data-open-bag="" aria-label="Abrir sacola">
          {"Sacola "}
          <span className="count" data-count="">
            {"0"}
          </span>
        </button>{" "}
        <div className="menu-drop" id="menu-drop">
          {" "}
          <ul>
            <li>
              <a href="#loja">{"Coleção"}</a>
            </li>
            <li>
              <a href="#looks">{"Looks"}</a>
            </li>
            <li>
              <a href="#sobre">{"Sobre"}</a>
            </li>
            <li>
              <a href="#visite">{"Visite a loja"}</a>
            </li>
          </ul>{" "}
        </div>{" "}
      </header>
    </>
  );
}
