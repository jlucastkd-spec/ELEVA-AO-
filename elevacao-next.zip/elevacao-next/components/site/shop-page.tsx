import type * as React from "react";
import { ShopItems } from "@/components/site/products";

// Gerado a partir do site original. Edite à vontade.
export function ShopPage() {
  return (
    <>
      <div className="shop" id="loja" role="dialog" aria-modal="true" aria-label="Coleção 2026" aria-hidden="true">
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <div className="shop-head wrap">
          {" "}
          <h1>{"Coleção 2026"}</h1>{" "}
          <p>{"Moletons, calças e conjuntos pretos de modelagem ampla. Clique na peça para escolher o tamanho."}</p>{" "}
        </div>{" "}
        <div className="filters wrap">
          {" "}
          <div className="chips" role="group" aria-label="Filtrar peças">
            {" "}
            <button type="button" data-filter="todos" aria-pressed="true">
              {"Todos"}
            </button>{" "}
            <button type="button" data-filter="moletom" aria-pressed="false">
              {"Moletons"}
            </button>{" "}
            <button type="button" data-filter="calca" aria-pressed="false">
              {"Calças"}
            </button>{" "}
            <button type="button" data-filter="conjunto" aria-pressed="false">
              {"Conjuntos"}
            </button>{" "}
            <button type="button" data-filter="camiseta" aria-pressed="false">
              {"Camisetas"}
            </button>{" "}
            <button type="button" data-filter="jaqueta" aria-pressed="false">
              {"Jaquetas"}
            </button>{" "}
            <button type="button" data-filter="acessorio" aria-pressed="false">
              {"Acessórios"}
            </button>{" "}
          </div>{" "}
          <span className="count-txt" id="shop-count"></span>{" "}
        </div>{" "}
        <div className="shop-grid" id="shop-grid">
          <ShopItems />
        </div>{" "}
        <div className="shop-foot">
          {" "}
          <button
            type="button"
            className="btn-out"
            data-shop-back=""
            style={
              {
                background: "none",
                color: "var(--ink)",
                cursor: "pointer",
                font: "inherit",
                fontSize: "12px",
              } as React.CSSProperties
            }
          >
            {"← Voltar para a página principal"}
          </button>{" "}
        </div>{" "}
      </div>
    </>
  );
}
