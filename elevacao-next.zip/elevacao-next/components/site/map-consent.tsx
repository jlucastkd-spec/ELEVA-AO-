const QUERY = "Rua+Augusta+1500+Sao+Paulo";

/** O mapa do Google só carrega depois que a pessoa permite (LGPD) */
export function MapConsent() {
  return (
    <div className="map-consent" id="map-box" data-src={`https://www.google.com/maps?q=${QUERY}&output=embed`}>
      <p>
        O mapa é fornecido pelo Google Maps, que recebe seu endereço IP e pode usar cookies. Ele só aparece aqui com a
        sua permissão. <a href="#cookies">Saiba mais</a>.
      </p>
      <div className="row">
        <button type="button" className="btn-out" data-load-map>
          Mostrar mapa aqui
        </button>
        <a
          className="btn-out"
          href={`https://www.google.com/maps/search/?api=1&query=${QUERY}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          Abrir no Google Maps
        </a>
      </div>
    </div>
  );
}
