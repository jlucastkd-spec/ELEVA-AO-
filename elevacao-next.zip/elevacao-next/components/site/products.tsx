import { COLLECTION, COLLECTION_SLOTS, SHOP, type ProductCard } from "@/lib/products";

type CardProps = { card: ProductCard; hidden?: boolean; withCat?: boolean };

/** Card de produto: abre a escolha de tamanho e sacola (tratado em lib/site-script.js) */
export function ProductCardView({ card, hidden = false, withCat = false }: CardProps) {
  return (
    <a
      href="#visite"
      className="prod"
      data-product={card.product}
      data-cat={withCat ? card.cat : undefined}
      aria-label={hidden ? undefined : `${card.name}, ${card.color}: escolher tamanho`}
      aria-hidden={hidden || undefined}
      tabIndex={hidden ? -1 : undefined}
    >
      <div className={`ph ${card.img}`} role="img" aria-label={card.aria}>
        <div className={`alt ph ${card.alt}`} />
      </div>
      <div className="cap">
        <span className="price">{card.label}</span>
        <span className="name">{card.name}</span>
        <span className="color">{card.color}</span>
      </div>
    </a>
  );
}

/** Espaço vazio "Em breve" */
export function SlotCard({ n, withCat = false }: { n: number; withCat?: boolean }) {
  const num = String(n).padStart(2, "0");
  return (
    <div
      className="prod slot"
      data-cat={withCat ? "vazio" : undefined}
      aria-label={`Espaço ${num}: nova peça em breve`}
    >
      <div className="ph">
        <b>+</b>
        <span>Nova peça em breve</span>
      </div>
      <div className="cap">
        <span className="price">{num}</span>
        <span className="name">Em breve</span>
        <span className="color">Espaço para nova roupa</span>
      </div>
    </div>
  );
}

/** Fileira que desliza: os cards se repetem uma vez para o loop não ter emenda */
export function RailItems({ cards }: { cards: ProductCard[] }) {
  return (
    <>
      {cards.map((c, i) => (
        <ProductCardView key={`a${i}`} card={c} />
      ))}
      {cards.map((c, i) => (
        <ProductCardView key={`b${i}`} card={c} hidden />
      ))}
    </>
  );
}

/** Coleção da página principal em páginas de 4 */
export function CollectionPages() {
  const items: (ProductCard | number)[] = [...COLLECTION];
  for (let n = COLLECTION.length + 1; n <= COLLECTION_SLOTS; n++) items.push(n);
  const pages: (ProductCard | number)[][] = [];
  for (let i = 0; i < items.length; i += 4) pages.push(items.slice(i, i + 4));
  return (
    <>
      {pages.map((page, p) => (
        <div className="page grid" key={p}>
          {page.map((it, i) =>
            typeof it === "number" ? <SlotCard key={i} n={it} /> : <ProductCardView key={i} card={it} />,
          )}
        </div>
      ))}
    </>
  );
}

/** Todas as peças na página "Ver tudo" */
export function ShopItems() {
  return (
    <>
      {SHOP.map((c, i) => (
        <ProductCardView key={i} card={c} withCat />
      ))}
    </>
  );
}
