import type * as React from "react";

// Gerado a partir do site original. Edite à vontade.
export function Overlays() {
  return (
    <>
      <section className="consent" id="consent" aria-labelledby="consent-t" hidden>
        {" "}
        <h2 id="consent-t">{"Sua privacidade"}</h2>{" "}
        <p>
          {
            "Guardamos no seu navegador só o essencial: sua sacola e suas preferências. O mapa do Google é um conteúdo de terceiros e só carrega se você permitir. As fontes vêm do Google Fonts. Veja a "
          }
          <a href="#cookies">{"Política de Cookies"}</a>
          {" e a "}
          <a href="#privacidade">{"Política de Privacidade"}</a>
          {"."}
        </p>{" "}
        <div className="row">
          {" "}
          <button type="button" className="primary" data-consent="all">
            {"Permitir mapa do Google"}
          </button>{" "}
          <button type="button" data-consent="essential">
            {"Só o essencial"}
          </button>{" "}
        </div>{" "}
      </section>
      <button type="button" className="motion-btn" id="motion-btn" aria-pressed="false">
        <svg viewBox="0 0 12 12" aria-hidden="true">
          <rect x="2" y="1" width="3" height="10" fill="currentColor" />
          <rect x="7" y="1" width="3" height="10" fill="currentColor" />
        </svg>
        <span>{"Pausar animações"}</span>
      </button>
      <div className="scrim" data-close-bag=""></div>
      <aside className="bag" id="bag" aria-label="Sacola" aria-hidden="true">
        {" "}
        <div className="bag-head">
          {" "}
          <h2>{"Sacola"}</h2>{" "}
          <button type="button" className="x-btn" data-close-bag="">
            {"Fechar"}
          </button>{" "}
        </div>{" "}
        <ul className="bag-items" id="bag-items"></ul>{" "}
        <div className="bag-foot" id="bag-foot" hidden>
          {" "}
          <div className="row">
            <span>{"Total"}</span>
            <span id="bag-total">{"R$ 0"}</span>
          </div>{" "}
          <small>
            {
              "Preços à vista. Retirada grátis na loja ou entrega com valor e prazo informados antes da confirmação. O pedido só vale depois que a loja confirmar por escrito no WhatsApp. Pagamento por Pix ou cartão."
            }
          </small>{" "}
          <label className="agree" htmlFor="agree">
            <input type="checkbox" id="agree" />
            <span>
              {"Li e concordo com os "}
              <a href="#termos" data-close-bag="">
                {"Termos de Uso"}
              </a>
              {", a "}
              <a href="#trocas" data-close-bag="">
                {"Política de Trocas"}
              </a>
              {" (arrependimento em 7 dias) e a "}
              <a href="#privacidade" data-close-bag="">
                {"Política de Privacidade"}
              </a>
              {"."}
            </span>
          </label>{" "}
          <p className="err" id="agree-err" role="alert"></p>{" "}
          <a className="checkout" id="checkout" href="#" target="_blank" rel="noopener noreferrer" aria-disabled="true">
            {"Finalizar pelo WhatsApp"}
          </a>{" "}
        </div>{" "}
      </aside>
      <dialog className="quick" id="quick" aria-labelledby="q-name">
        {" "}
        <button type="button" className="x-btn q-close" data-close-quick="">
          {"Fechar"}
        </button>{" "}
        <div className="quick-grid">
          {" "}
          <div className="q-img" id="q-img"></div>{" "}
          <div className="q-body">
            {" "}
            <h3 id="q-name"></h3> <p className="q-price" id="q-price"></p> <p className="q-desc" id="q-desc"></p>{" "}
            <div>
              {" "}
              <p
                className="meta"
                id="q-color"
                style={{ fontSize: "12px", color: "var(--mute)", marginBottom: "8px" } as React.CSSProperties}
              >
                {"Cor: Preto"}
              </p>{" "}
              <div className="opts text" id="q-sizes"></div>{" "}
            </div>{" "}
            <p className="form-msg" id="q-msg" role="status"></p>{" "}
            <button type="button" className="btn-out add-look" id="q-add">
              {"Adicionar à sacola"}
            </button>{" "}
            <ul className="q-info">
              <li>{"Preço à vista. Pagamento por Pix ou cartão, combinado no WhatsApp."}</li>
              <li>{"Retirada grátis na loja ou entrega com frete informado antes da confirmação."}</li>
              <li>
                {"Arrependimento em até 7 dias e troca em 30 dias. "}
                <a href="#trocas" data-close-quick="">
                  {"Ver política"}
                </a>
              </li>
              <li>{"Imagem ilustrativa; a cor pode variar conforme a tela."}</li>
            </ul>{" "}
          </div>{" "}
        </div>{" "}
      </dialog>
      <div className="toast" id="toast" role="status" aria-live="polite"></div>
    </>
  );
}
