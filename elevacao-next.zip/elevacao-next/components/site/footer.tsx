import type * as React from "react";
import { Co } from "@/components/site/co";

// Gerado a partir do site original. Edite à vontade.
export function SiteFooter() {
  return (
    <>
      <footer className="foot wrap">
        {" "}
        <div>
          {" "}
          <h4>{"Coleções"}</h4>{" "}
          <ul>
            <li>
              <a href="#loja">{"Halo"}</a>
            </li>
            <li>
              <a href="#loja">{"Capuz"}</a>
            </li>
            <li>
              <a href="#loja">{"Pregas"}</a>
            </li>
            <li>
              <a href="#loja">{"Conjuntos"}</a>
            </li>
          </ul>{" "}
        </div>{" "}
        <div>
          {" "}
          <h4>{"Looks"}</h4>{" "}
          <ul>
            <li>
              <a href="#looks">{"Todos os looks"}</a>
            </li>
          </ul>{" "}
        </div>{" "}
        <div>
          {" "}
          <h4>{"Info"}</h4>{" "}
          <ul>
            <li>
              <a href="#sobre">{"Sobre"}</a>
            </li>
            <li>
              <a href="#visite">{"Endereço e horário"}</a>
            </li>
            <li>
              <a href="https://wa.me/5511999999999" data-co-href="whatsapp" target="_blank" rel="noopener noreferrer">
                {"WhatsApp"}
              </a>
            </li>
            <li>
              <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer">
                {"Instagram"}
              </a>
            </li>
          </ul>{" "}
        </div>{" "}
        <div>
          {" "}
          <h4>{"Legal"}</h4>{" "}
          <ul>
            <li>
              <a href="#privacidade">{"Política de Privacidade"}</a>
            </li>
            <li>
              <a href="#termos">{"Termos de Uso"}</a>
            </li>
            <li>
              <a href="#trocas">{"Trocas e Devoluções"}</a>
            </li>
            <li>
              <a href="#cookies">{"Política de Cookies"}</a>
            </li>
            <li>
              <a href="#acessibilidade">{"Acessibilidade"}</a>
            </li>
            <li>
              <a href="#seus-dados">{"Seus dados (LGPD)"}</a>
            </li>
            <li>
              <button type="button" className="link-btn" data-open-consent="">
                {"Preferências de cookies"}
              </button>
            </li>
          </ul>{" "}
        </div>{" "}
        <div className="brand">
          {" "}
          <a href="#inicio" className="logo">
            {"Elevação"}
          </a>{" "}
          <small>{"São Paulo"}</small> <p>{"© 2026 Elevação"}</p>{" "}
        </div>{" "}
        <div className="legal">
          {" "}
          <p>
            <Co k="razao" />
            {" · CNPJ "}
            <Co k="cnpj" />
          </p>{" "}
          <p>
            <Co k="endereco" />
          </p>{" "}
          <p>
            {"Atendimento: "}
            <Co k="email" />
            {" · WhatsApp "}
            <Co k="whatsappTxt" />
            {" · "}
            <Co k="horario" />
          </p>{" "}
          <p>{"Preços em reais, à vista. Imagens ilustrativas; as cores podem variar conforme a tela."}</p>{" "}
        </div>{" "}
      </footer>
    </>
  );
}
