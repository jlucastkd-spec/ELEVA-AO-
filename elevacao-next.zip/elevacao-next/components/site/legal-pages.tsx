import type * as React from "react";
import { Co } from "@/components/site/co";

// Gerado a partir do site original. Edite à vontade.
export function LegalPages() {
  return (
    <>
      <div
        className="shop doc"
        id="privacidade"
        role="dialog"
        aria-modal="true"
        aria-labelledby="privacidade-t"
        aria-hidden="true"
      >
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <article className="doc-body wrap">
          {" "}
          <header className="shop-head">
            {" "}
            <h1 id="privacidade-t">{"Política de Privacidade"}</h1>{" "}
            <p>
              {
                "Como a Elevação trata seus dados pessoais, de acordo com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD)."
              }
            </p>{" "}
            <p className="doc-date">{"Última atualização: 31 de outubro de 2026"}</p>{" "}
          </header>{" "}
          <nav className="toc" aria-label="Nesta página">
            {" "}
            <a href="#pv-1">{"Quem somos"}</a>
            <a href="#pv-2">{"Dados coletados"}</a>
            <a href="#pv-3">{"Finalidades e bases legais"}</a>
            <a href="#pv-4">{"Compartilhamento"}</a>
            <a href="#pv-5">{"Transferência internacional"}</a>
            <a href="#pv-6">{"Armazenamento e segurança"}</a>
            <a href="#pv-7">{"Prazos"}</a>
            <a href="#pv-8">{"Seus direitos"}</a>
            <a href="#pv-9">{"Contato"}</a>{" "}
          </nav>{" "}
          <section id="pv-1">
            <h2>{"1. Quem é o responsável pelos seus dados"}</h2>{" "}
            <p>
              {"O controlador dos dados pessoais tratados por meio deste site é "}
              <Co k="razao" />
              {", nome fantasia Elevação, inscrita no CNPJ sob o nº "}
              <Co k="cnpj" />
              {", com endereço em "}
              <Co k="endereco" />
              {"."}
            </p>{" "}
            <p>
              {"Encarregado pelo tratamento de dados pessoais (art. 41 da LGPD): "}
              <Co k="encarregado" />
              {", pelo e-mail "}
              <Co k="emailPriv" />
              {"."}
            </p>{" "}
          </section>{" "}
          <section id="pv-2">
            <h2>{"2. Quais dados coletamos"}</h2>{" "}
            <p>
              {
                "Este site não tem cadastro, login nem formulário que envie dados para um servidor nosso. Os dados chegam até nós por estes caminhos:"
              }
            </p>{" "}
            <div className="tbl-wrap">
              <table>
                <caption className="sr-only">{"Dados pessoais tratados"}</caption>
                <thead>
                  <tr>
                    <th scope="col">{"Situação"}</th>
                    <th scope="col">{"Dados"}</th>
                    <th scope="col">{"Onde ficam"}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{"Uso da sacola"}</td>
                    <td>{"Peças, cores, tamanhos e quantidades escolhidas"}</td>
                    <td>
                      {
                        "Somente no seu navegador (armazenamento local). Não recebemos esses dados até você finalizar o pedido."
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>{"Preferências do site"}</td>
                    <td>{"Sua escolha sobre cookies e sobre pausar animações"}</td>
                    <td>{"Somente no seu navegador"}</td>
                  </tr>
                  <tr>
                    <td>{"Pedido pelo WhatsApp"}</td>
                    <td>{"Nome, telefone, itens do pedido, endereço de entrega (se houver) e forma de pagamento"}</td>
                    <td>{"Na conversa do WhatsApp da loja e no nosso controle de vendas"}</td>
                  </tr>
                  <tr>
                    <td>{"Solicitações sobre seus dados"}</td>
                    <td>{"Nome, e-mail, telefone (opcional) e o conteúdo do pedido"}</td>
                    <td>{"No e-mail ou WhatsApp da loja"}</td>
                  </tr>
                  <tr>
                    <td>{"Acesso ao site"}</td>
                    <td>{"Endereço IP, data e hora, navegador e página acessada (registros técnicos)"}</td>
                    <td>{"Na empresa de hospedagem do site"}</td>
                  </tr>
                  <tr>
                    <td>{"Mapa do Google (opcional)"}</td>
                    <td>{"Endereço IP e cookies do Google, somente se você permitir"}</td>
                    <td>{"Google"}</td>
                  </tr>
                </tbody>
              </table>
            </div>{" "}
            <p>
              {
                "Não coletamos dados sensíveis (art. 5º, II, da LGPD) nem dados de cartão. O pagamento é feito por Pix, cartão na maquininha ou link de pagamento combinado no atendimento, e os dados do cartão ficam com a instituição de pagamento."
              }
            </p>{" "}
            <p>
              {
                "O site não é direcionado a menores de 18 anos. Compras por crianças e adolescentes devem ser feitas pelos pais ou responsáveis."
              }
            </p>{" "}
          </section>{" "}
          <section id="pv-3">
            <h2>{"3. Para que usamos e com qual base legal"}</h2>{" "}
            <div className="tbl-wrap">
              <table>
                <caption className="sr-only">{"Finalidades e bases legais"}</caption>
                <thead>
                  <tr>
                    <th scope="col">{"Finalidade"}</th>
                    <th scope="col">{"Base legal (LGPD)"}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{"Montar a sacola e lembrar dela quando você volta"}</td>
                    <td>{"Execução de contrato ou de procedimentos preliminares a pedido do titular (art. 7º, V)"}</td>
                  </tr>
                  <tr>
                    <td>{"Atender, confirmar e entregar seu pedido, emitir nota fiscal e combinar pagamento"}</td>
                    <td>
                      {
                        "Execução de contrato (art. 7º, V) e cumprimento de obrigação legal ou regulatória (art. 7º, II)"
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>{"Atender trocas, devoluções e garantia"}</td>
                    <td>
                      {
                        "Cumprimento de obrigação legal (art. 7º, II — Código de Defesa do Consumidor) e exercício regular de direitos (art. 7º, VI)"
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>{"Responder solicitações sobre seus dados"}</td>
                    <td>{"Cumprimento de obrigação legal (art. 7º, II, e art. 18)"}</td>
                  </tr>
                  <tr>
                    <td>{"Registros de acesso ao site"}</td>
                    <td>
                      {
                        "Cumprimento de obrigação legal (art. 15 do Marco Civil da Internet) e legítimo interesse em manter o site seguro (art. 7º, IX)"
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>{"Carregar fontes tipográficas do Google Fonts"}</td>
                    <td>{"Legítimo interesse em exibir o site corretamente (art. 7º, IX)"}</td>
                  </tr>
                  <tr>
                    <td>{"Exibir o mapa do Google"}</td>
                    <td>{"Consentimento (art. 7º, I), que você pode retirar a qualquer momento"}</td>
                  </tr>
                </tbody>
              </table>
            </div>{" "}
            <p>
              {
                "Não usamos seus dados para publicidade, não vendemos dados e não fazemos decisões automatizadas sobre você."
              }
            </p>{" "}
          </section>{" "}
          <section id="pv-4">
            <h2>{"4. Com quem compartilhamos"}</h2>{" "}
            <ul>
              <li>
                <strong>{"Hospedagem do site:"}</strong>
                {" Vercel Inc., que recebe os registros técnicos de acesso."}
              </li>
              <li>
                <strong>{"Mensagens:"}</strong>
                {" WhatsApp (Meta Platforms), por onde os pedidos são feitos."}
              </li>
              <li>
                <strong>{"Google:"}</strong>
                {" Google Fonts, para as fontes, e Google Maps, somente se você permitir o mapa."}
              </li>
              <li>
                <strong>{"Pagamento e entrega:"}</strong>
                {
                  " instituição de pagamento e transportadora ou entregador, apenas com os dados necessários para concluir o pedido."
                }
              </li>
              <li>
                <strong>{"Contabilidade e autoridades:"}</strong>
                {" quando houver obrigação legal, como emissão de nota fiscal, ou ordem judicial."}
              </li>
            </ul>{" "}
          </section>{" "}
          <section id="pv-5">
            <h2>{"5. Transferência internacional"}</h2>{" "}
            <p>
              {
                "Vercel, Meta e Google podem armazenar ou processar dados em servidores fora do Brasil, principalmente nos Estados Unidos. Essas transferências seguem o art. 33 da LGPD, com base nas cláusulas contratuais e nas garantias de proteção de dados oferecidas por essas empresas."
              }
            </p>{" "}
          </section>{" "}
          <section id="pv-6">
            <h2>{"6. Como armazenamos e protegemos"}</h2>{" "}
            <ul>
              <li>
                {
                  "O site é servido apenas por conexão segura (HTTPS) e usa cabeçalhos de segurança que bloqueiam conteúdo de origens não autorizadas."
                }
              </li>
              <li>
                {
                  "A sacola e as preferências ficam só no seu navegador. Você pode apagá-las limpando os dados do site no navegador."
                }
              </li>
              <li>
                {"As conversas e os dados de pedidos são acessados apenas pela equipe da loja que faz o atendimento."}
              </li>
              <li>
                {
                  "Em caso de incidente de segurança que possa causar risco relevante, avisaremos os titulares afetados e a Autoridade Nacional de Proteção de Dados (ANPD), como determina o art. 48 da LGPD."
                }
              </li>
            </ul>{" "}
          </section>{" "}
          <section id="pv-7">
            <h2>{"7. Por quanto tempo guardamos"}</h2>{" "}
            <ul>
              <li>
                <strong>{"Pedidos e notas fiscais:"}</strong>
                {" 5 anos, pelo prazo das obrigações fiscais e do Código de Defesa do Consumidor (art. 27)."}
              </li>
              <li>
                <strong>{"Registros de acesso ao site:"}</strong>
                {" 6 meses (art. 15 do Marco Civil da Internet)."}
              </li>
              <li>
                <strong>{"Solicitações sobre dados pessoais:"}</strong>
                {" 5 anos, para comprovar o atendimento."}
              </li>
              <li>
                <strong>{"Sacola e preferências no navegador:"}</strong>
                {" até você apagar ou finalizar o pedido."}
              </li>
            </ul>{" "}
            <p>{"Depois desses prazos, os dados são apagados ou anonimizados."}</p>{" "}
          </section>{" "}
          <section id="pv-8">
            <h2>{"8. Seus direitos"}</h2> <p>{"Pelo art. 18 da LGPD, você pode pedir a qualquer momento:"}</p>{" "}
            <ul>
              <li>{"confirmação de que tratamos seus dados e acesso a eles;"}</li>
              <li>{"correção de dados incompletos, inexatos ou desatualizados;"}</li>
              <li>
                {
                  "anonimização, bloqueio ou eliminação de dados desnecessários ou tratados em desconformidade com a lei;"
                }
              </li>
              <li>{"portabilidade dos dados a outro fornecedor;"}</li>
              <li>{"eliminação dos dados tratados com seu consentimento;"}</li>
              <li>{"informação sobre com quem compartilhamos seus dados;"}</li>
              <li>{"informação sobre a possibilidade de não dar consentimento e as consequências disso;"}</li>
              <li>{"revogação do consentimento;"}</li>
              <li>{"oposição a tratamento feito sem consentimento, quando houver descumprimento da lei;"}</li>
              <li>{"revisão de decisões tomadas só com base em tratamento automatizado."}</li>
            </ul>{" "}
            <p>
              {
                "Respondemos em até 15 dias (art. 19, II). Para sua segurança, podemos pedir uma confirmação de identidade antes de atender. Você também pode reclamar à ANPD em "
              }
              <a href="https://www.gov.br/anpd" target="_blank" rel="noopener noreferrer">
                {"gov.br/anpd"}
              </a>
              {"."}
            </p>{" "}
          </section>{" "}
          <section id="pv-9">
            <h2>{"9. Como falar com a gente"}</h2>{" "}
            <p>
              {"Use o "}
              <a href="#seus-dados">{"formulário de solicitação de dados"}</a>
              {", escreva para "}
              <Co k="emailPriv" />
              {" ou chame no WhatsApp "}
              <Co k="whatsappTxt" />
              {"."}
            </p>{" "}
            <p>{"Esta política pode ser atualizada. A data da última versão fica no topo desta página."}</p>{" "}
          </section>{" "}
          <p className="doc-back">
            <button type="button" className="btn-out" data-shop-back="">
              {"← Voltar para a página principal"}
            </button>
          </p>{" "}
        </article>{" "}
      </div>
      <div
        className="shop doc"
        id="termos"
        role="dialog"
        aria-modal="true"
        aria-labelledby="termos-t"
        aria-hidden="true"
      >
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <article className="doc-body wrap">
          {" "}
          <header className="shop-head">
            {" "}
            <h1 id="termos-t">{"Termos de Uso"}</h1>{" "}
            <p>{"As regras para usar este site e fazer pedidos na Elevação."}</p>{" "}
            <p className="doc-date">{"Última atualização: 31 de outubro de 2026"}</p>{" "}
          </header>{" "}
          <section>
            <h2>{"1. Quem somos"}</h2>{" "}
            <p>
              {"Este site pertence a "}
              <Co k="razao" />
              {" (Elevação), CNPJ "}
              <Co k="cnpj" />
              {", com loja física em "}
              <Co k="endereco" />
              {". Contato: "}
              <Co k="email" />
              {" e WhatsApp "}
              <Co k="whatsappTxt" />
              {", "}
              <Co k="horario" />
              {"."}
            </p>{" "}
            <p>
              {"Ao usar o site, você concorda com estes Termos e com a "}
              <a href="#privacidade">{"Política de Privacidade"}</a>
              {"."}
            </p>{" "}
          </section>{" "}
          <section>
            <h2>{"2. O que o site faz"}</h2>{" "}
            <ul>
              <li>{"Mostra as peças da loja, com fotos, descrição, tamanhos e preços."}</li>
              <li>{"Permite montar uma sacola, que fica salva apenas no seu navegador."}</li>
              <li>{"Gera uma mensagem com o pedido para você enviar pelo WhatsApp da loja."}</li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"3. O que o site não faz"}</h2>{" "}
            <ul>
              <li>{"Não processa pagamentos nem guarda dados de cartão."}</li>
              <li>{"Não reserva estoque. A disponibilidade é confirmada pela loja no atendimento."}</li>
              <li>
                {
                  "Montar a sacola não é uma compra. O pedido só existe depois que a loja confirma por escrito no WhatsApp os itens, o valor total, o frete, a forma de pagamento e o prazo de entrega ou retirada."
                }
              </li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"4. Preços, pagamento e entrega"}</h2>{" "}
            <ul>
              <li>
                {
                  "Os preços estão em reais (R$) e são preços à vista. Condições de parcelamento, se houver, são informadas antes da confirmação do pedido."
                }
              </li>
              <li>
                {
                  "Se houver diferença entre o preço do site e o confirmado no atendimento por erro evidente, informaremos antes do pagamento e você pode desistir sem custo."
                }
              </li>
              <li>
                {"Retirada na loja é gratuita. O valor e o prazo da entrega são informados antes da confirmação."}
              </li>
              <li>{"As fotos são ilustrativas e as cores podem variar conforme a tela."}</li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"5. Trocas, devoluções e arrependimento"}</h2>{" "}
            <p>
              {"Valem as regras da "}
              <a href="#trocas">{"Política de Trocas e Devoluções"}</a>
              {
                ", incluindo o direito de arrependimento em até 7 dias para compras feitas fora da loja física (art. 49 do Código de Defesa do Consumidor)."
              }
            </p>{" "}
          </section>{" "}
          <section>
            <h2>{"6. Responsabilidades de quem usa o site"}</h2>{" "}
            <ul>
              <li>{"Informar dados corretos no pedido."}</li>
              <li>{"Não tentar invadir, sobrecarregar ou alterar o funcionamento do site."}</li>
              <li>
                {
                  "Não copiar fotos, textos, marca ou identidade visual da Elevação para uso comercial sem autorização (Lei nº 9.610/1998 e Lei nº 9.279/1996)."
                }
              </li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"7. Responsabilidades da Elevação"}</h2>{" "}
            <ul>
              <li>{"Manter informações claras sobre produtos, preços e condições (arts. 6º e 31 do CDC)."}</li>
              <li>{"Cumprir a oferta confirmada no atendimento (art. 30 do CDC)."}</li>
              <li>{"Proteger os dados pessoais conforme a Política de Privacidade."}</li>
            </ul>{" "}
            <p>
              {
                "O site pode ficar fora do ar por manutenção ou falha técnica. Links para outros sites, como WhatsApp, Instagram e Google, seguem as regras desses serviços."
              }
            </p>{" "}
          </section>{" "}
          <section>
            <h2>{"8. Atendimento e reclamações"}</h2>{" "}
            <p>
              {"Fale com a gente por "}
              <Co k="email" />
              {" ou WhatsApp "}
              <Co k="whatsappTxt" />
              {". Respondemos em até 5 dias úteis (Decreto nº 7.962/2013). Você também pode registrar reclamação em "}
              <a href="https://www.consumidor.gov.br" target="_blank" rel="noopener noreferrer">
                {"consumidor.gov.br"}
              </a>
              {" ou no Procon."}
            </p>{" "}
          </section>{" "}
          <section>
            <h2>{"9. Lei e foro"}</h2>{" "}
            <p>
              {
                "Estes Termos seguem a lei brasileira. Fica eleito o foro do domicílio do consumidor para resolver qualquer questão."
              }
            </p>{" "}
          </section>{" "}
          <p className="doc-back">
            <button type="button" className="btn-out" data-shop-back="">
              {"← Voltar para a página principal"}
            </button>
          </p>{" "}
        </article>{" "}
      </div>
      <div
        className="shop doc"
        id="cookies"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cookies-t"
        aria-hidden="true"
      >
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <article className="doc-body wrap">
          {" "}
          <header className="shop-head">
            {" "}
            <h1 id="cookies-t">{"Política de Cookies"}</h1>{" "}
            <p>{"O que o site guarda no seu navegador e o que é carregado de outros serviços."}</p>{" "}
            <p className="doc-date">{"Última atualização: 31 de outubro de 2026"}</p>{" "}
          </header>{" "}
          <section>
            <h2>{"1. O que usamos"}</h2>{" "}
            <div className="tbl-wrap">
              <table>
                <caption className="sr-only">{"Armazenamento e conteúdos de terceiros"}</caption>
                <thead>
                  <tr>
                    <th scope="col">{"Nome"}</th>
                    <th scope="col">{"Tipo"}</th>
                    <th scope="col">{"Para que serve"}</th>
                    <th scope="col">{"Duração"}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{"elevacao-sacola"}</td>
                    <td>{"Essencial (armazenamento local)"}</td>
                    <td>{"Guardar as peças da sua sacola"}</td>
                    <td>{"Até você apagar ou esvaziar a sacola"}</td>
                  </tr>
                  <tr>
                    <td>{"elevacao-consentimento"}</td>
                    <td>{"Essencial (armazenamento local)"}</td>
                    <td>{"Lembrar sua escolha sobre cookies e a data dela"}</td>
                    <td>{"12 meses"}</td>
                  </tr>
                  <tr>
                    <td>{"elevacao-movimento"}</td>
                    <td>{"Essencial (armazenamento local)"}</td>
                    <td>{"Lembrar se você pausou as animações"}</td>
                    <td>{"Até você mudar"}</td>
                  </tr>
                  <tr>
                    <td>{"Google Fonts"}</td>
                    <td>{"Terceiro, sem cookies"}</td>
                    <td>{"Carregar as fontes do site. O Google recebe seu IP."}</td>
                    <td>{"Não se aplica"}</td>
                  </tr>
                  <tr>
                    <td>{"Google Maps"}</td>
                    <td>{"Terceiro, opcional"}</td>
                    <td>{"Mostrar o mapa da loja. Pode criar cookies do Google."}</td>
                    <td>{"Definida pelo Google"}</td>
                  </tr>
                </tbody>
              </table>
            </div>{" "}
            <p>{"Não usamos cookies de publicidade nem de rastreamento."}</p>{" "}
          </section>{" "}
          <section>
            <h2>{"2. Como escolher"}</h2>{" "}
            <p>
              {
                "Na primeira visita você escolhe entre aceitar o conteúdo de terceiros ou ficar só com o essencial. O mapa só carrega se você permitir. Para mudar sua escolha a qualquer momento:"
              }
            </p>{" "}
            <p>
              <button type="button" className="btn-out" data-open-consent="">
                {"Preferências de cookies"}
              </button>
            </p>{" "}
            <p>{"Você também pode apagar os dados do site nas configurações do navegador."}</p>{" "}
          </section>{" "}
          <p className="doc-back">
            <button type="button" className="btn-out" data-shop-back="">
              {"← Voltar para a página principal"}
            </button>
          </p>{" "}
        </article>{" "}
      </div>
      <div
        className="shop doc"
        id="trocas"
        role="dialog"
        aria-modal="true"
        aria-labelledby="trocas-t"
        aria-hidden="true"
      >
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <article className="doc-body wrap">
          {" "}
          <header className="shop-head">
            {" "}
            <h1 id="trocas-t">{"Trocas e Devoluções"}</h1>{" "}
            <p>{"Seus direitos como consumidor e como pedir troca, devolução ou reembolso."}</p>{" "}
            <p className="doc-date">{"Última atualização: 31 de outubro de 2026"}</p>{" "}
          </header>{" "}
          <section>
            <h2>{"1. Direito de arrependimento (7 dias)"}</h2>{" "}
            <p>
              {"Se você comprou pelo WhatsApp ou pelo site, ou seja, fora da loja física, pode desistir em até "}
              <strong>{"7 dias corridos"}</strong>
              {" contados do recebimento, sem precisar explicar o motivo (art. 49 do Código de Defesa do Consumidor)."}
            </p>{" "}
            <ul>
              <li>
                {"Avise pelo WhatsApp "}
                <Co k="whatsappTxt" />
                {" ou por "}
                <Co k="email" />
                {"."}
              </li>
              <li>
                {
                  "Devolvemos todo o valor pago, incluindo o frete, pelo mesmo meio de pagamento, em até 10 dias depois de recebermos a peça."
                }
              </li>
              <li>
                {
                  "Se você pagou com cartão, pedimos o estorno à operadora imediatamente (art. 5º do Decreto nº 7.962/2013)."
                }
              </li>
              <li>{"O custo de envio da devolução é nosso."}</li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"2. Troca por tamanho ou cor"}</h2>{" "}
            <p>
              {"Trocamos peças sem uso, com etiqueta, em até "}
              <strong>{"30 dias"}</strong>
              {
                " da compra, na loja ou pelo WhatsApp, conforme a disponibilidade de estoque. Essa troca é uma cortesia da loja e não substitui os direitos garantidos por lei."
              }
            </p>{" "}
          </section>{" "}
          <section>
            <h2>{"3. Produto com defeito"}</h2>{" "}
            <ul>
              <li>
                {"Você tem até "}
                <strong>{"90 dias"}</strong>
                {
                  " para reclamar de defeito em roupas, que são produtos duráveis (art. 26, II, do CDC). Defeitos que só aparecem com o uso contam a partir de quando forem notados."
                }
              </li>
              <li>
                {
                  "Temos até 30 dias para resolver. Se não resolvermos, você escolhe entre a troca por outra peça, a devolução do valor ou o abatimento do preço (art. 18 do CDC)."
                }
              </li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"4. Como pedir"}</h2>{" "}
            <ol>
              <li>{"Mande uma mensagem com seu nome, o número ou a data do pedido e o que aconteceu."}</li>
              <li>{"Combinamos a coleta, o envio ou a entrega na loja."}</li>
              <li>{"Conferimos a peça e fazemos a troca ou o reembolso nos prazos acima."}</li>
            </ol>{" "}
            <p>
              {"Endereço para devolução e troca: "}
              <Co k="endereco" />
              {". Horário: "}
              <Co k="horario" />
              {"."}
            </p>{" "}
          </section>{" "}
          <p className="doc-back">
            <button type="button" className="btn-out" data-shop-back="">
              {"← Voltar para a página principal"}
            </button>
          </p>{" "}
        </article>{" "}
      </div>
      <div
        className="shop doc"
        id="acessibilidade"
        role="dialog"
        aria-modal="true"
        aria-labelledby="acessibilidade-t"
        aria-hidden="true"
      >
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <article className="doc-body wrap">
          {" "}
          <header className="shop-head">
            {" "}
            <h1 id="acessibilidade-t">{"Acessibilidade"}</h1>{" "}
            <p>
              {
                "Nosso compromisso para que todas as pessoas consigam usar o site (Lei nº 13.146/2015 — Lei Brasileira de Inclusão)."
              }
            </p>{" "}
            <p className="doc-date">{"Última atualização: 31 de outubro de 2026"}</p>{" "}
          </header>{" "}
          <section>
            <h2>{"O que fizemos"}</h2>{" "}
            <ul>
              <li>
                {
                  "Seguimos como referência as Diretrizes de Acessibilidade para Conteúdo Web (WCAG 2.1, nível AA) e o eMAG."
                }
              </li>
              <li>{'Link "Pular para o conteúdo" no início da página, para quem navega pelo teclado.'}</li>
              <li>{"Todo o site funciona pelo teclado, com o foco sempre visível."}</li>
              <li>
                {
                  'Botão "Pausar animações" fixo na tela, que para o vídeo, as fileiras de produtos e os demais movimentos. O site também respeita a configuração de reduzir movimento do seu aparelho.'
                }
              </li>
              <li>{"Imagens com descrição em texto e formulários com rótulos e mensagens de erro claras."}</li>
              <li>{"Contraste de cores revisado para leitura confortável."}</li>
              <li>{"Páginas que se adaptam a celular, tablet e computador, e ao aumento de zoom até 200%."}</li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"Limitações conhecidas"}</h2>{" "}
            <ul>
              <li>
                {
                  "As fotos de produtos ainda não têm descrição detalhada de caimento e medidas. Se precisar, pedimos que fale com a gente para receber as informações por escrito."
                }
              </li>
              <li>
                {
                  "O mapa do Google é um serviço externo e pode não ser totalmente acessível. O endereço completo está escrito na seção Visite a loja."
                }
              </li>
            </ul>{" "}
          </section>{" "}
          <section>
            <h2>{"Encontrou alguma barreira?"}</h2>{" "}
            <p>
              {"Conte para a gente por "}
              <Co k="email" />
              {" ou WhatsApp "}
              <Co k="whatsappTxt" />
              {". Respondemos em até 5 dias úteis e oferecemos atendimento alternativo enquanto corrigimos."}
            </p>{" "}
          </section>{" "}
          <p className="doc-back">
            <button type="button" className="btn-out" data-shop-back="">
              {"← Voltar para a página principal"}
            </button>
          </p>{" "}
        </article>{" "}
      </div>
      <div
        className="shop doc"
        id="seus-dados"
        role="dialog"
        aria-modal="true"
        aria-labelledby="seus-dados-t"
        aria-hidden="true"
      >
        {" "}
        <div className="shop-bg" aria-hidden="true"></div>{" "}
        <div className="shop-top wrap">
          {" "}
          <button type="button" className="back" data-shop-back="" aria-label="Voltar para a página principal">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M20 12H4M10 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{"Voltar"}</span>
          </button>{" "}
          <span className="logo">{"Elevação"}</span>{" "}
          <button type="button" className="cart-btn" data-open-bag="" aria-label="Abrir sacola">
            {"Sacola "}
            <span className="count" data-count="">
              {"0"}
            </span>
          </button>{" "}
        </div>{" "}
        <article className="doc-body wrap">
          {" "}
          <header className="shop-head">
            {" "}
            <h1 id="seus-dados-t">{"Seus dados (LGPD)"}</h1>{" "}
            <p>{"Peça acesso, correção, exclusão ou outra solicitação sobre seus dados pessoais."}</p>{" "}
            <p className="doc-date">{"Última atualização: 31 de outubro de 2026"}</p>{" "}
          </header>{" "}
          <form className="form" id="lgpd-form" noValidate>
            {" "}
            <p className="form-note">
              {
                "Campos com * são obrigatórios. Este formulário não envia nada sozinho: ao final, ele prepara a mensagem para você enviar por e-mail ou WhatsApp. Usamos esses dados apenas para responder à sua solicitação, como explica a "
              }
              <a href="#privacidade">{"Política de Privacidade"}</a>
              {"."}
            </p>{" "}
            <div className="field">
              {" "}
              <label htmlFor="lg-nome">{"Nome completo *"}</label>{" "}
              <input
                id="lg-nome"
                name="nome"
                type="text"
                autoComplete="name"
                maxLength={120}
                required
                aria-describedby="lg-nome-err"
              />{" "}
              <p className="err" id="lg-nome-err"></p>{" "}
            </div>{" "}
            <div className="field">
              {" "}
              <label htmlFor="lg-email">{"E-mail *"}</label>{" "}
              <input
                id="lg-email"
                name="email"
                type="email"
                autoComplete="email"
                maxLength={160}
                required
                aria-describedby="lg-email-err"
              />{" "}
              <p className="err" id="lg-email-err"></p>{" "}
            </div>{" "}
            <div className="field">
              {" "}
              <label htmlFor="lg-tel">{"Telefone (opcional)"}</label>{" "}
              <input id="lg-tel" name="tel" type="tel" autoComplete="tel" maxLength={20} inputMode="tel" />{" "}
            </div>{" "}
            <div className="field">
              {" "}
              <label htmlFor="lg-tipo">{"O que você quer pedir? *"}</label>{" "}
              <select id="lg-tipo" name="tipo" required aria-describedby="lg-tipo-err">
                <option value="">{"Escolha uma opção"}</option>
                <option>{"Confirmar se vocês têm meus dados"}</option>
                <option>{"Acessar meus dados"}</option>
                <option>{"Corrigir meus dados"}</option>
                <option>{"Anonimizar, bloquear ou eliminar dados"}</option>
                <option>{"Portabilidade dos meus dados"}</option>
                <option>{"Saber com quem meus dados foram compartilhados"}</option>
                <option>{"Revogar meu consentimento"}</option>
                <option>{"Me opor a um tratamento"}</option>
                <option>{"Outro assunto sobre privacidade"}</option>
              </select>{" "}
              <p className="err" id="lg-tipo-err"></p>{" "}
            </div>{" "}
            <div className="field">
              {" "}
              <label htmlFor="lg-msg">{"Detalhes (opcional)"}</label>{" "}
              <textarea id="lg-msg" name="msg" rows={4} maxLength={1000} aria-describedby="lg-msg-hint"></textarea>{" "}
              <p className="hint" id="lg-msg-hint">
                {"Até 1.000 caracteres. Não envie documentos nem senhas por aqui."}
              </p>{" "}
            </div>{" "}
            <div className="hp" aria-hidden="true">
              <label htmlFor="lg-site">{"Não preencha"}</label>
              <input id="lg-site" name="site" type="text" tabIndex={-1} autoComplete="off" />
            </div>{" "}
            <div className="field check">
              {" "}
              <input id="lg-ok" name="ok" type="checkbox" required aria-describedby="lg-ok-err" />{" "}
              <label htmlFor="lg-ok">
                {
                  "Declaro que sou o titular dos dados ou seu representante legal e que as informações são verdadeiras. *"
                }
              </label>{" "}
              <p className="err" id="lg-ok-err"></p>{" "}
            </div>{" "}
            <button type="submit" className="btn-out add-look">
              {"Preparar solicitação"}
            </button>{" "}
          </form>{" "}
          <div className="result" id="lgpd-result" hidden tabIndex={-1}>
            {" "}
            <h2>{"Solicitação pronta"}</h2>{" "}
            <p>
              {"Protocolo: "}
              <strong id="lg-proto"></strong>
              {". Guarde esse número. Envie a mensagem por um dos canais abaixo. Respondemos em até 15 dias."}
            </p>{" "}
            <pre id="lg-text"></pre>{" "}
            <div className="result-actions">
              {" "}
              <a className="btn-out add-look" id="lg-mail" href="#">
                {"Enviar por e-mail"}
              </a>{" "}
              <a className="btn-out" id="lg-wpp" href="#" target="_blank" rel="noopener noreferrer">
                {"Enviar pelo WhatsApp"}
              </a>{" "}
              <button type="button" className="btn-out" id="lg-copy">
                {"Copiar texto"}
              </button>{" "}
            </div>{" "}
            <p className="hint">
              {"E-mail do encarregado: "}
              <Co k="emailPriv" />
            </p>{" "}
          </div>{" "}
          <p className="doc-back">
            <button type="button" className="btn-out" data-shop-back="">
              {"← Voltar para a página principal"}
            </button>
          </p>{" "}
        </article>{" "}
      </div>
    </>
  );
}
