"use client";

import { useEffect } from "react";
import { CATALOG } from "@/lib/products";
import { EMPRESA } from "@/lib/site-config";
import { initSite } from "@/lib/site-script";

/** Liga a sacola, as páginas legais, os cookies e as animações depois que a página monta */
export function SiteScripts() {
  useEffect(() => {
    initSite({ empresa: EMPRESA, products: CATALOG });
  }, []);
  return null;
}
