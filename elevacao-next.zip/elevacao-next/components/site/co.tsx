import { EMPRESA, type EmpresaKey } from "@/lib/site-config";

/** Mostra um dado da empresa (razão social, CNPJ, e-mail...) definido em lib/site-config.ts */
export function Co({ k }: { k: EmpresaKey }) {
  return <span data-co={k}>{EMPRESA[k]}</span>;
}
