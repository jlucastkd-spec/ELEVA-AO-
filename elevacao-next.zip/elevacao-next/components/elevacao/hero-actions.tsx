"use client"

import { ArrowRight, MessageCircle } from "lucide-react"
import { LiquidButton } from "@/components/ui/liquid-glass-button"
import { EMPRESA } from "@/lib/site-config"

/** Botões de vidro do início: abrem a coleção e o WhatsApp da loja */
export function HeroActions() {
  return (
    <div className="hero-actions">
      <LiquidButton size="xl" className="liquid" onClick={() => { window.location.hash = "loja" }}>
        <span className="inline-flex items-center gap-2">
          Ver a coleção <ArrowRight className="size-4" aria-hidden />
        </span>
      </LiquidButton>
      <LiquidButton
        size="xl"
        className="liquid"
        onClick={() => window.open(`https://wa.me/${EMPRESA.whatsapp}`, "_blank", "noopener,noreferrer")}
      >
        <span className="inline-flex items-center gap-2">
          <MessageCircle className="size-4" aria-hidden /> Chamar no WhatsApp
        </span>
      </LiquidButton>
    </div>
  )
}
