// Catálogo da Elevação. Para adicionar uma peça: inclua no CATALOG
// (usado pela sacola) e nas listas de vitrine abaixo.

export type CatalogItem = {
  name: string;
  price: number;
  img: string;
  desc: string;
  color?: string;
  sizes?: string[];
};

export const CATALOG: Record<string, CatalogItem> = {
  "moletom-halo": {
    name: "Moletom Halo",
    price: 289,
    img: "i-hood-front",
    desc: "Capuz alto, ombro caído e felpa por dentro.",
  },
  "calca-pregas": {
    name: "Calça Pregas",
    price: 259,
    img: "i-pants-front",
    desc: "Perna larga, pregas nas laterais e botões até a barra.",
  },
  "conjunto-halo": {
    name: "Conjunto Halo",
    price: 519,
    img: "i-full-front",
    desc: "Moletom Halo e Calça Pregas no mesmo tamanho. Sai R$ 29 mais barato que separado.",
  },
  "jaqueta-mons": {
    name: "Jaqueta Mons",
    price: 349,
    img: "i-p-jaq-front",
    desc: "Jaqueta puffer leve, gola alta, zíper frontal e bolsos laterais.",
  },
  "camiseta-hang": {
    name: "Camiseta Hang Loose",
    price: 149,
    img: "i-p-hang",
    desc: "Camiseta de algodão com o símbolo Hang Loose no peito.",
  },
  "camiseta-klnd": {
    name: "Camiseta KLND",
    price: 169,
    img: "i-p-klnd",
    desc: "Camiseta preta de malha pesada com o nome KLND pequeno no peito.",
  },
  "camiseta-hang-branca": {
    name: "Camiseta Hang Loose Branca",
    price: 149,
    img: "i-q-hang-branca",
    color: "Branco",
    desc: "Camiseta branca de algodão com o nome Hang Loose em vermelho no peito.",
  },
  "polo-hang": {
    name: "Polo Hang Loose",
    price: 189,
    img: "i-q-polo",
    desc: "Camisa polo preta de piquet, com etiqueta pequena do símbolo no peito.",
  },
  "camiseta-rusty": {
    name: "Camiseta Rusty",
    price: 159,
    img: "i-q-rusty",
    color: "Verde",
    desc: "Camiseta verde-oliva com o logo Rusty International no peito.",
  },
  "camiseta-rusty-surf": {
    name: "Camiseta Rusty Surfboards",
    price: 159,
    img: "i-q-rusty-surf",
    color: "Branco",
    desc: "Camiseta branca com o selo Rusty Surfboards grande nas costas.",
  },
  "regata-hang": {
    name: "Regata Hang Loose",
    price: 79.9,
    img: "i-q-regata",
    desc: "Regata preta de algodão com o nome e o símbolo Hang Loose no peito.",
  },
  "bone-klnd": {
    name: "Boné KLND",
    price: 129,
    img: "i-p-bone",
    color: "Bege",
    sizes: ["Único"],
    desc: "Boné de aba curva em sarja bege, com bordado tom sobre tom e regulagem atrás.",
  },
};

export type ProductCard = {
  /** classe da foto principal */
  img: string;
  /** classe da foto que aparece ao passar o mouse */
  alt: string;
  /** preço ou número mostrado no card */
  label: string;
  name: string;
  color: string;
  /** descrição da foto para leitores de tela */
  aria: string;
  /** id no CATALOG */
  product: string;
  /** filtro da página da coleção */
  cat?: string;
};

export const RAIL_TOP: ProductCard[] = [
  {
    img: "i-hood-front",
    alt: "i-full-front",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto",
    aria: "Moletom Halo preto, de frente",
    product: "moletom-halo",
  },
  {
    img: "i-pants-front",
    alt: "i-full-34",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto",
    aria: "Calça Pregas preta, de frente",
    product: "calca-pregas",
  },
  {
    img: "i-hood-back",
    alt: "i-full-back",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto · costas",
    aria: "Costas do Moletom Halo com estrela branca",
    product: "moletom-halo",
  },
  {
    img: "i-full-side",
    alt: "i-hood-side",
    label: "R$ 519",
    name: "Conjunto Halo",
    color: "Moletom + calça",
    aria: "Conjunto Halo visto de lado",
    product: "conjunto-halo",
  },
  {
    img: "i-pants-side",
    alt: "i-full-side",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto · lateral",
    aria: "Lateral da Calça Pregas com botões",
    product: "calca-pregas",
  },
  {
    img: "i-hood-side",
    alt: "i-full-front",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto · manga",
    aria: "Manga do Moletom Halo com estampa",
    product: "moletom-halo",
  },
];

export const RAIL_BOTTOM: ProductCard[] = [
  {
    img: "i-full-side",
    alt: "i-hood-side",
    label: "R$ 519",
    name: "Conjunto Halo",
    color: "Moletom + calça",
    aria: "Conjunto Halo visto de lado",
    product: "conjunto-halo",
  },
  {
    img: "i-hood-front",
    alt: "i-full-front",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto",
    aria: "Moletom Halo preto, de frente",
    product: "moletom-halo",
  },
  {
    img: "i-pants-side",
    alt: "i-full-side",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto · lateral",
    aria: "Lateral da Calça Pregas com botões",
    product: "calca-pregas",
  },
  {
    img: "i-hood-back",
    alt: "i-full-back",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto · costas",
    aria: "Costas do Moletom Halo com estrela branca",
    product: "moletom-halo",
  },
  {
    img: "i-hood-side",
    alt: "i-full-front",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto · manga",
    aria: "Manga do Moletom Halo com estampa",
    product: "moletom-halo",
  },
  {
    img: "i-pants-front",
    alt: "i-full-34",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto",
    aria: "Calça Pregas preta, de frente",
    product: "calca-pregas",
  },
];

/** Coleção da página principal: 4 por página; o restante vira "Em breve" */
export const COLLECTION: ProductCard[] = [
  {
    img: "i-hood-front",
    alt: "i-full-front",
    label: "01",
    name: "Halo",
    color: "Moletom de capuz e calça larga",
    aria: "Coleção Halo: moletom preto de frente",
    product: "conjunto-halo",
  },
  {
    img: "i-q-hang-branca",
    alt: "i-q-hang-branca-det",
    label: "R$ 149",
    name: "Camiseta Hang Loose Branca",
    color: "Branco",
    aria: "Camiseta branca Hang Loose usada na praia",
    product: "camiseta-hang-branca",
  },
  {
    img: "i-q-polo",
    alt: "i-q-polo-det",
    label: "R$ 189",
    name: "Polo Hang Loose",
    color: "Preto",
    aria: "Camisa polo preta Hang Loose",
    product: "polo-hang",
  },
  {
    img: "i-q-rusty",
    alt: "i-q-rusty-det",
    label: "R$ 159",
    name: "Camiseta Rusty",
    color: "Verde",
    aria: "Camiseta Rusty verde-oliva com logo no peito",
    product: "camiseta-rusty",
  },
  {
    img: "i-p-jaq-front",
    alt: "i-p-jaq-back",
    label: "R$ 349",
    name: "Jaqueta Mons",
    color: "Preto",
    aria: "Jaqueta Mons preta, puffer de gola alta",
    product: "jaqueta-mons",
  },
  {
    img: "i-p-hang",
    alt: "i-p-hang-det",
    label: "R$ 149",
    name: "Camiseta Hang Loose",
    color: "Preto",
    aria: "Camiseta Hang Loose preta com símbolo no peito",
    product: "camiseta-hang",
  },
  {
    img: "i-p-klnd",
    alt: "i-p-klnd-det",
    label: "R$ 169",
    name: "Camiseta KLND",
    color: "Preto",
    aria: "Camiseta KLND preta, detalhe do nome no peito",
    product: "camiseta-klnd",
  },
  {
    img: "i-p-bone",
    alt: "i-p-bone-det",
    label: "R$ 129",
    name: "Boné KLND",
    color: "Bege",
    aria: "Boné KLND bege com bordado tom sobre tom",
    product: "bone-klnd",
  },
  {
    img: "i-q-rusty-surf",
    alt: "i-q-rusty-surf-det",
    label: "R$ 159",
    name: "Camiseta Rusty Surfboards",
    color: "Branco",
    aria: "Costas da camiseta branca Rusty Surfboards",
    product: "camiseta-rusty-surf",
  },
  {
    img: "i-q-regata",
    alt: "i-q-regata-det",
    label: "R$ 79,90",
    name: "Regata Hang Loose",
    color: "Preto",
    aria: "Regata preta Hang Loose com símbolo no peito",
    product: "regata-hang",
  },
];

export const COLLECTION_SLOTS = 12;

/** Página "Ver tudo" */
export const SHOP: ProductCard[] = [
  {
    img: "i-hood-front",
    alt: "i-full-front",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto",
    aria: "Moletom Halo preto, de frente",
    product: "moletom-halo",
    cat: "moletom",
  },
  {
    img: "i-pants-front",
    alt: "i-full-34",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto",
    aria: "Calça Pregas preta, de frente",
    product: "calca-pregas",
    cat: "calca",
  },
  {
    img: "i-hood-back",
    alt: "i-full-back",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto · costas",
    aria: "Costas do Moletom Halo com estrela branca",
    product: "moletom-halo",
    cat: "moletom",
  },
  {
    img: "i-full-side",
    alt: "i-hood-side",
    label: "R$ 519",
    name: "Conjunto Halo",
    color: "Moletom + calça",
    aria: "Conjunto Halo visto de lado",
    product: "conjunto-halo",
    cat: "conjunto",
  },
  {
    img: "i-pants-side",
    alt: "i-full-side",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto · lateral",
    aria: "Lateral da Calça Pregas com botões",
    product: "calca-pregas",
    cat: "calca",
  },
  {
    img: "i-hood-side",
    alt: "i-full-front",
    label: "R$ 289",
    name: "Moletom Halo",
    color: "Preto · manga",
    aria: "Manga do Moletom Halo com estampa",
    product: "moletom-halo",
    cat: "moletom",
  },
  {
    img: "i-full-back",
    alt: "i-full-34",
    label: "R$ 519",
    name: "Conjunto Halo",
    color: "Preto · costas",
    aria: "Conjunto Halo de costas",
    product: "conjunto-halo",
    cat: "conjunto",
  },
  {
    img: "i-pants-front",
    alt: "i-pants-side",
    label: "R$ 259",
    name: "Calça Pregas",
    color: "Preto · detalhe",
    aria: "Calça Pregas em detalhe",
    product: "calca-pregas",
    cat: "calca",
  },
  {
    img: "i-p-jaq-front",
    alt: "i-p-jaq-back",
    label: "R$ 349",
    name: "Jaqueta Mons",
    color: "Preto",
    aria: "Jaqueta Mons preta, puffer de gola alta",
    product: "jaqueta-mons",
    cat: "jaqueta",
  },
  {
    img: "i-p-hang",
    alt: "i-p-hang-det",
    label: "R$ 149",
    name: "Camiseta Hang Loose",
    color: "Preto",
    aria: "Camiseta Hang Loose preta com símbolo no peito",
    product: "camiseta-hang",
    cat: "camiseta",
  },
  {
    img: "i-p-klnd",
    alt: "i-p-klnd-det",
    label: "R$ 169",
    name: "Camiseta KLND",
    color: "Preto",
    aria: "Camiseta KLND preta, detalhe do nome no peito",
    product: "camiseta-klnd",
    cat: "camiseta",
  },
  {
    img: "i-p-bone",
    alt: "i-p-bone-det",
    label: "R$ 129",
    name: "Boné KLND",
    color: "Bege",
    aria: "Boné KLND bege com bordado tom sobre tom",
    product: "bone-klnd",
    cat: "acessorio",
  },
  {
    img: "i-q-hang-branca",
    alt: "i-q-hang-branca-det",
    label: "R$ 149",
    name: "Camiseta Hang Loose Branca",
    color: "Branco",
    aria: "Camiseta branca Hang Loose usada na praia",
    product: "camiseta-hang-branca",
    cat: "camiseta",
  },
  {
    img: "i-q-polo",
    alt: "i-q-polo-det",
    label: "R$ 189",
    name: "Polo Hang Loose",
    color: "Preto",
    aria: "Camisa polo preta Hang Loose",
    product: "polo-hang",
    cat: "camiseta",
  },
  {
    img: "i-q-rusty",
    alt: "i-q-rusty-det",
    label: "R$ 159",
    name: "Camiseta Rusty",
    color: "Verde",
    aria: "Camiseta Rusty verde-oliva com logo no peito",
    product: "camiseta-rusty",
    cat: "camiseta",
  },
  {
    img: "i-q-rusty-surf",
    alt: "i-q-rusty-surf-det",
    label: "R$ 159",
    name: "Camiseta Rusty Surfboards",
    color: "Branco",
    aria: "Costas da camiseta branca Rusty Surfboards",
    product: "camiseta-rusty-surf",
    cat: "camiseta",
  },
  {
    img: "i-q-regata",
    alt: "i-q-regata-det",
    label: "R$ 79,90",
    name: "Regata Hang Loose",
    color: "Preto",
    aria: "Regata preta Hang Loose com símbolo no peito",
    product: "regata-hang",
    cat: "camiseta",
  },
];
