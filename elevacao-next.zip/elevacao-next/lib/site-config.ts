// Dados da empresa: troque aqui e o site inteiro é atualizado.
export const EMPRESA = {
  razao: "[Razão social]",
  cnpj: "[CNPJ]",
  endereco: "Rua Augusta, 1500 — Consolação, São Paulo/SP, CEP [00000-000]",
  email: "[e-mail de contato]",
  emailPriv: "[e-mail de privacidade]",
  whatsapp: "5511999999999",
  whatsappTxt: "(11) 99999-9999",
  encarregado: "[nome do encarregado]",
  horario: "Seg a sex, 10h às 20h · Sábado, 10h às 18h",
} as const;

export type EmpresaKey = keyof typeof EMPRESA;
