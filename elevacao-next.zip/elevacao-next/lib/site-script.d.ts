import type { CatalogItem } from "./products"

export function initSite(cfg: { empresa: Readonly<Record<string, string>>; products: Record<string, CatalogItem> }): void
